package thesis.controllers;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import thesis.configs.models.structures.AccountInfo;
import thesis.entities.AccountEntity;
import thesis.entities.AccountRoleEntity;
import thesis.entities.RoleEntity;
import thesis.repositories.AccountRepository;
import thesis.repositories.AccountRoleRepository;
import thesis.repositories.RoleRepository;
import thesis.utils.AccountUtils;

@Controller
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	private AccountRepository accountRepository;

	@Autowired
	private RoleRepository roleRepository;

	@Autowired
	private AccountRoleRepository accountRoleRepository;

	@GetMapping(value = "/dashboard")
	public String dashboard(Model model) {
		return "layouts/admin/pages/dashboard";
	}

	@GetMapping(value = "/show-account")
	public String showAccount(Model model) {
		List<AccountInfo> accountInfos = new ArrayList<AccountInfo>();

		List<AccountEntity> accounts = (List<AccountEntity>) accountRepository.findAll();
		List<RoleEntity> roleEntities = (List<RoleEntity>) this.roleRepository.findAll();

		if (!CollectionUtils.isEmpty(accounts)) {
			for (AccountEntity accountEntity : accounts) {
				List<AccountRoleEntity> accountRoleEntities = this.accountRoleRepository
						.findByAccountId(accountEntity.getId());
				RoleEntity roleEntity = new RoleEntity();
				for (AccountRoleEntity accountRoleEntity : accountRoleEntities) {
					roleEntity = AccountUtils._getRoleByRoleId(roleEntities, accountRoleEntity.getRoleId());
				}
				AccountInfo accountInfo = AccountUtils._mappingAttributeFromEntities(accountEntity, roleEntity);
				accountInfos.add(accountInfo);
			}
		}

		model.addAttribute("accountInfos", accountInfos);
		return "layouts/admin/pages/show-account";
	}

	@GetMapping(value = "/add-account")
	public String addAccount(Model model) {
		model.addAttribute("account", new AccountInfo());
		List<RoleEntity> roleEntities = (List<RoleEntity>) this.roleRepository.findAll();

		model.addAttribute("roles", roleEntities);
		model.addAttribute("action", "add");
		return "layouts/admin/pages/account-form";
	}

	@PostMapping(value = "/result")
	public String confirmadd(Model model, @ModelAttribute("account") AccountInfo account) {

		AccountEntity accountEntity = AccountUtils._mappingAttributeFromAccountMode(account);
		accountEntity = accountRepository.save(accountEntity);
		RoleEntity roleEntity = roleRepository.findByRoleCodeLike(account.getRoleCode());
		if (accountEntity.getId() > 0 && roleEntity != null && roleEntity.getId() > 0) {
			AccountRoleEntity accountRoleEntity = new AccountRoleEntity();
			if (account.getAccountRoleId() > 0) {
				Optional<AccountRoleEntity> accountRole = accountRoleRepository.findById(account.getAccountRoleId());
				if(accountRole.isPresent()) {
					accountRoleEntity.setId(accountRole.get().getId());
				}
			}
			accountRoleEntity.setAccountId(accountEntity.getId());
			accountRoleEntity.setRoleId(roleEntity.getId());
			accountRoleRepository.save(accountRoleEntity);
		}

		return "redirect:/admin/show-account";
	}

	@GetMapping(value = "/update")
	public String addAccount(Model model, @RequestParam("accId") int accId) {
		AccountInfo accountInfo = new AccountInfo();
		Optional<AccountEntity> accountEntity = accountRepository.findById(accId);
		int accountRoleId = 0;
		List<RoleEntity> roleEntities = (List<RoleEntity>) this.roleRepository.findAll();
		if (accountEntity.isPresent()) {
			AccountEntity account = accountEntity.get();
			List<AccountRoleEntity> accountRoleEntities = this.accountRoleRepository.findByAccountId(account.getId());
			RoleEntity roleEntity = new RoleEntity();
			for (AccountRoleEntity accountRoleEntity : accountRoleEntities) {
				roleEntity = AccountUtils._getRoleByRoleId(roleEntities, accountRoleEntity.getRoleId());
				accountRoleId = accountRoleEntity.getId();
			}
			accountInfo = AccountUtils._mappingAttributeFromEntities(account, roleEntity);
			accountInfo.setAccountRoleId(accountRoleId);
		}

		model.addAttribute("account", accountInfo);
		model.addAttribute("roles", roleEntities);
		model.addAttribute("action", "update");
		return "layouts/admin/pages/account-form";
	}

	@ModelAttribute("name")
	public String modelDisplayname() {
		String name = "Long Pham";
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if (auth != null) {
			AccountEntity accountEntity = this.accountRepository.findOneByEmail(auth.getName());
			if (accountEntity != null) {
				name = accountEntity.getFullName();
			}
		}
		return name;
	}
}
