package thesis.controllers;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

	@GetMapping(value = { "/", "/home" })
	public String index() {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if (auth.isAuthenticated()) {
			for (GrantedAuthority item : auth.getAuthorities()) {
				if(item.getAuthority().contentEquals("ROLE_ADMIN")) {
					return "redirect:/admin/dashboard";
				}
			}
			
			return "redirect:/user/dashboard";
		} else {
			return "redirect:/sign-in";
		}
	}
}
