package thesis.controllers;

import java.io.File;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;

import thesis.configs.models.structures.MyFile;
import thesis.entities.AccountEntity;
import thesis.repositories.AccountRepository;

@Controller
@RequestMapping("/user")
public class UserController {

	@Autowired
	private AccountRepository accountRepository;

	@GetMapping(value = "/dashboard")
	public String dashboard(Model model) {
		return "layouts/user/pages/dashboard";
	}

	@GetMapping(value = "/uploadFile")
	public String uploadPage(Model model) {
		model.addAttribute("myFile", new MyFile());
		return "layouts/user/pages/upload-form";
	}

	@PostMapping(value = "/result")
	public String uploadFile(Model model, MyFile myFile) {
		System.out.println("======upload file=====>");
		model.addAttribute("message", "Upload success");
		model.addAttribute("description", myFile.getDescription());
		try {
			MultipartFile multipartFile = myFile.getMultipartFile();
			String fileName = multipartFile.getOriginalFilename();
			File file = new File(this.getFolderUpload(), fileName);
			multipartFile.transferTo(file);
		} catch (Exception e) {
			e.printStackTrace();
			model.addAttribute("message", "Upload failed");
		}
		return "layouts/user/pages/upload-form";
	}
	
	public File getFolderUpload() {
	    File folderUpload = new File(System.getProperty("user.home") + "/Uploads");
	    
	    System.out.println("======hahaha=====>"+System.getProperty("user.home") + "/Uploads");
	    if (!folderUpload.exists()) {
	      folderUpload.mkdirs();
	    }
	    return folderUpload;
	  }

	@ModelAttribute("name")
	public String modelDisplayname() {
		String name = "Long Pham";
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if (auth != null) {
			AccountEntity accountEntity = this.accountRepository.findOneByEmail(auth.getName());
			if (accountEntity != null) {
				name = accountEntity.getFullName();
			}
		}
		return name;
	}
}
